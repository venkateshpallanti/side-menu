# MaterialAutocompleteDemo

# Get Started

Run `npm install`

# Run it

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. 

If port 4200 is not available run `ng serve --port=4202` 

Because this uses another module like material.module.ts generating a component will require you to add --module=app

Example: ng g c components/component-name --module=app
