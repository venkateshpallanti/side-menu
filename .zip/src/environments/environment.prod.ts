export const environment = {
  production: true,
  openSideNav: true
};
